import sys
sys.path.append('C:/ComputerSimulations/')
import numpy as np 
import matplotlib.pyplot as plt
from tqdm import tqdm
import os
from time import time
from _numsolvers import methods as meth
import numba as nb
from numba import njit
from scipy.ndimage import convolve, generate_binary_structure


def main():


    return


def get_lattice(L,spinRatio = 0.5):
    random = np.random.random((L,L))
    lattice = np.zeros((L,L))
    lattice[random>=spinRatio] = 1
    lattice[random<spinRatio] = -1
    return lattice

def sweep(lattice):
    convolution_mask = generate_binary_structure(2,1)
    convolution_mask[1,1] = False
    E = -lattice*convolve(lattice,convolution_mask,mode="wrap")
    print(lattice)
    print("#######################")
    i = 2
    lattice[i,i] = lattice[i,i]*(-1)
    print(lattice)
    print("#######################")
    start = time()
    #for i in tqdm(range(1000000)):
    E2 = -lattice*convolve(lattice,convolution_mask,mode="wrap")
    end = time()
    dE = lattice[i-1:i+2,i-1:i+2]
    smoll = -dE*convolve(dE, convolution_mask, mode="constant",cval=0)
    print("#######################")
    print("dE \n",dE)
    print(end-start , " s")
    print("#######################")
    print("E1 \n", E)
    print("#######################")
    print("E2 \n" ,E2)
    print("#######################")
    print("smoll \n", smoll)
    print("#######################")
    print("E2-E1 \n",E2-E)
    print("#######################")
    return 


d = [1,2,3,4,5,6,7]
print(d[2:])
i = 0
j = 0
lattice = get_lattice(10)
print(lattice)
print("#############################F")
lattice[i,j] = 100
print(lattice)
for n in range(2):
            lattice[i,(j+(-1)**n)%len(lattice)] = 50
            lattice[(i+(-1)**n)%len(lattice),j] = 50
print("#############################F")
print(lattice)
for n in range(2):
        print(i,(j+(-1)**n)%len(lattice))
        print((i+(-1)**n)%len(lattice),j)
          
print("#############################F")
def Metro_Hast_1D(sampleProb, deltaX, N , x0 ,disable_pgb= True ):
    #if optimize is true, the function will calculate a guess for deltax and use it for the markovchain 
    x_random = np.zeros(N) #initialize
    x_random[0]  = x0

    for i in tqdm(range(1,N), desc = "Metro Hasting Main Loop", disable= disable_pgb):
        x_next = x_random[i-1] + (np.random.random() -0.5)*deltaX
        #i assign the acceptance probability randomly if p_i/p_j < 1, Z_j -> Z_i 
        if sampleProb(x_next)/sampleProb(x_random[i-1]) > np.random.random():
            x_random[i] = x_next
            
            
        else:
            x_random[i] = x_random[i-1]
        
    return x_random , deltaX






















import sys
sys.path.append('C:/ComputerSimulations/')
import numpy as np 
import matplotlib.pyplot as plt
from tqdm import tqdm
import os
from time import time
from _numsolvers import methods as meth
import numba as nb
from numba import njit
from scipy.ndimage import convolve, generate_binary_structure


def main():


    return


def get_lattice(L,spinRatio = 0.5):
    random = np.random.random((L,L))
    lattice = np.zeros((L,L))
    lattice[random>=spinRatio] = 1
    lattice[random<spinRatio] = -1
    return lattice
#@njit("UniTuple(f8[:], 2)(f8[:,:], f8[:,:], f8, i8, b1)", nopython=True, nogil=True)
def sweep(lattice ,convolution_mask,beta, L, show_pic = False):
    
    E0 = -lattice*convolve(lattice,convolution_mask,mode="wrap")
    all_Energies = np.zeros(L)
    all_Magnets = np.zeros(L)
    all_Energies[0] = E0.sum()
    all_Magnets[0] = lattice.sum()
    
    for t in tqdm(range(1,L)):
        old_lattice = lattice.copy()
        i,j = np.random.randint(0,len(lattice)-1,1) , np.random.randint(0,len(lattice)-1,1)
        #i,j = int(20*np.cos(2*t + np.random.random())*np.cos(t) + 40), int(20*np.cos(2*t + np.random.random())*np.sin(t) + 40)
        lattice[i,j] *= -1
        E_t = -lattice*convolve(lattice,convolution_mask, mode = "wrap")
        E_t = E_t.sum()
        if np.exp(-beta*(E_t-all_Energies[t-1])) < np.random.random():
            lattice = old_lattice
            all_Energies[t] = all_Energies[t-1]
            all_Magnets[t] = all_Magnets[t-1]
        else:
            all_Energies[t] = E_t
            all_Magnets[t]  = lattice.sum()
        
        if (t%1 == 0) and (show_pic == True):
            fig, ax = plt.subplots(1,3, figsize= (16,9))
            ax[0].imshow(lattice)
            ax[1].scatter(np.arange(0,t,1), all_Energies[0:t],color = "b")
            ax[2].scatter(np.arange(0,t,1),all_Magnets[0:t])
            plt.show(block=False)
            plt.pause(0.001)
            ax[0].cla()
            ax[1].cla()
            ax[2].cla()
            
    return all_Energies,all_Magnets
lattice = get_lattice(10,spinRatio=0.5)
convolution_mask = generate_binary_structure(2,1)
convolution_mask[1,1] = False

E0 = -lattice*convolve(lattice,convolution_mask,mode="wrap")
l1 = -lattice[4,4]*(lattice[3,4] + lattice[5,4]+ lattice[4,3] + lattice[4,5])
lattice[4,4] = lattice[4,4]*(-1)
l2 = -lattice[4,4]*(lattice[3,4] + lattice[5,4]+ lattice[4,3] + lattice[4,5])
E1 = -lattice*convolve(lattice,convolution_mask,mode="wrap")
print(l2 -l1)
print(E1.sum()- E0.sum())
print(E1-E0)
#E,M = sweep(get_lattice(100,spinRatio=0.5),convolution_mask ,0.9,L=1000000)
#plt.plot(E)
#plt.show()
#plt.plot(M)
#plt.show()
def Metro_Hast_1D(sampleProb, deltaX, N , x0 ,disable_pgb= True ):
    #if optimize is true, the function will calculate a guess for deltax and use it for the markovchain 
    x_random = np.zeros(N) #initialize
    x_random[0]  = x0

    for i in tqdm(range(1,N), desc = "Metro Hasting Main Loop", disable= disable_pgb):
        x_next = x_random[i-1] + (np.random.random() -0.5)*deltaX
        #i assign the acceptance probability randomly if p_i/p_j < 1, Z_j -> Z_i 
        if sampleProb(x_next)/sampleProb(x_random[i-1]) > np.random.random():
            x_random[i] = x_next
            
            
        else:
            x_random[i] = x_random[i-1]
        
    return x_random , deltaX




















def sweep(lattice ,convolution_mask,beta, L):
    
    E0 = -lattice*convolve(lattice,convolution_mask,mode="wrap")
    all_Energies = np.zeros(L)
    all_Magnets = np.zeros(L)
    all_Energies[0] = E0.sum()
    all_Magnets[0] = lattice.sum()
    
    for t in tqdm(range(1,L)):
        #start = time()
        old_lattice = lattice.copy()
        #end = time()
        #print("########firstpart: ", end - start)
        i,j = np.random.randint(0,len(lattice)-1,1) , np.random.randint(0,len(lattice)-1,1)
        #i,j = int(20*np.cos(2*t + np.random.random())*np.cos(t) + 40), int(20*np.cos(2*t + np.random.random())*np.sin(t) + 40)
        #start = time()
        lattice[i,j] *= -1
        E_t = -lattice*convolve(lattice,convolution_mask, mode = "wrap")
        #end = time()
        #print("########secondpart: ", end - start)
        E_t = E_t.sum()
        if np.exp(-beta*(E_t-all_Energies[t-1])) < np.random.random():
            lattice = old_lattice
            all_Energies[t] = all_Energies[t-1]
            all_Magnets[t] = all_Magnets[t-1]
        else:
            all_Energies[t] = E_t
            all_Magnets[t]  = lattice.sum()


A = [1,2,3,4,5,6,7]
for i in range(0,-5):
    print(A[i%len(A)])



print(5%3)
print(5//3)