import numpy as np
import matplotlib.pyplot as plt
import numba
from numba import njit
from scipy.ndimage import convolve, generate_binary_structure
from time import time
import matplotlib.style as mplstyle
import matplotlib as mpl
from tqdm import tqdm
N = 2
init_random = np.random.random((N,N))
lattice_n = np.zeros((N, N))
lattice_n[init_random>=0.5] = 1
lattice_n[init_random<0.5] = -1

init_random = np.random.random((N,N))
lattice_p = np.zeros((N, N))
lattice_p[init_random>=0.25] = 1
lattice_p[init_random<0.25] = -1
def get_energy(lattice):
    # applies the nearest neighbours summation
    kern = generate_binary_structure(2, 1) 
    kern[1][1] = False
    arr = -lattice * convolve(lattice, kern, mode='constant', cval=0)
    return arr.sum()
@numba.njit("UniTuple(f8[:], 2)(f8[:,:], i8, f8, f8)", nopython=True, nogil=True)
def metropolis(spin_arr, times, BJ, energy):
    spin_arr = spin_arr.copy()
    net_spins = np.zeros(times-1)
    net_energy = np.zeros(times-1)
    for t in range(0,times-1):
        # 2. pick random point on array and flip spin
        x = np.random.randint(0,N)
        y = np.random.randint(0,N)
        spin_i = spin_arr[x,y] #initial spin
        spin_f = spin_i*-1 #proposed spin flip
        
        # compute change in energy
        E_i = 0
        E_f = 0
        if x>0:
            E_i += -spin_i*spin_arr[x-1,y]
            E_f += -spin_f*spin_arr[x-1,y]
        if x<N-1:
            E_i += -spin_i*spin_arr[x+1,y]
            E_f += -spin_f*spin_arr[x+1,y]
        if y>0:
            E_i += -spin_i*spin_arr[x,y-1]
            E_f += -spin_f*spin_arr[x,y-1]
        if y<N-1:
            E_i += -spin_i*spin_arr[x,y+1]
            E_f += -spin_f*spin_arr[x,y+1]
        
        # 3 / 4. change state with designated probabilities
        dE = E_f-E_i
        if (dE>0)*(np.random.random() < np.exp(-BJ*dE)):
            spin_arr[x,y]=spin_f
            energy += dE
        elif dE<=0:
            spin_arr[x,y]=spin_f
            energy += dE
            
        net_spins[t] = spin_arr.sum()
        net_energy[t] = energy
            
    return net_spins, net_energy
#start = time()
#spins, energies = metropolis(lattice_n, 1000000, 1.75, get_energy(lattice_n))
#end = time()
#print("s",end-start)
#fig, axes = plt.subplots(1, 2, figsize=(12,4))
#ax = axes[0]
#ax.plot(spins/N**2)
#ax.set_xlabel('Algorithm Time Steps')
#ax.set_ylabel(r'Average Spin $\bar{m}$')
#ax.grid()
#ax = axes[1]
#ax.plot(energies)
#ax.set_xlabel('Algorithm Time Steps')
#ax.set_ylabel(r'Energy $E/J$')
#ax.grid()
#fig.tight_layout()
#fig.suptitle(r'Evolution of Average Spin and Energy for $\beta J=$0.7', y=1.07, size=18)
#plt.show()
def auto_time(auto):
    for i in range(len(auto)):
        if np.abs(auto[i]) < 0.07:
            zeroindex = i
            break
    time = np.sum(auto[:zeroindex])
    return time ,zeroindex

def get_cmap(n, name='hsv'):
    '''Returns a function that maps each index in 0, 1, ..., n-1 to a distinct 
    RGB color; the keyword argument name must be a standard mpl colormap name.'''
    return plt.cm.get_cmap(name, n)

def get_energy(lattice):
    convolution_mask = generate_binary_structure(2,1)
    convolution_mask[1,1] = False
    Energy =  -lattice*convolve(lattice,convolution_mask, mode = "wrap")/2
    Energy = Energy.sum()
    return Energy

def get_lattice(L,spinRatio = 0.5):
    random = np.random.random((L,L))
    lattice = np.zeros((L,L))
    lattice[random>=spinRatio] = 1
    lattice[random<spinRatio] = -1
    return lattice

@njit( nopython=True, nogil=True)
def fastsweep(lattice ,beta, L, startEnergy):
    all_Energies = np.zeros(L)
    all_Magnets = np.zeros(L)
    all_Energies[0] = startEnergy
    all_Magnets[0] = lattice.sum()
    for t in range(1,L):
        E_p = 0
        E_t = 0
        old_lattice = lattice.copy()
        i = np.random.randint(0,len(lattice)) 
        j = np.random.randint(0,len(lattice))
        flipped_spin = lattice[i,j] 
        lattice[i,j] = flipped_spin*(-1)
        for n in range(2):
            E_t += lattice[i,(j+(-1)**n)%len(lattice)]
            E_t += lattice[(i+(-1)**n)%len(lattice),j]
            E_p += old_lattice[i,(j+(-1)**n)%len(lattice)]
            E_p += old_lattice[(i+(-1)**n)%len(lattice),j]

        E_t = -E_t*lattice[i,j]
        E_p = -E_p*flipped_spin
        deltaE = E_t-E_p
        if np.exp(-beta*(deltaE)) < np.random.random():
            lattice = old_lattice
            all_Energies[t] = all_Energies[t-1]
            all_Magnets[t] = all_Magnets[t-1]
        else:
            all_Energies[t] = deltaE + all_Energies[t-1]
            all_Magnets[t]  = lattice.sum()
        if t%100000 == 0:
            print(t/L,"%")
        
    return all_Energies,all_Magnets, lattice

lattice = get_lattice(8)
energy = get_energy(lattice)
#e, m  = sweep(lattice,0.5,1000000,energy)
start = time()
e, m , lattice = fastsweep(lattice,0.6,64000000,energy)
end = time()
print((end - start)//60, (end-start)%60)
plt.plot(e)
plt.show() 
plt.plot(m)
plt.show()
print(get_energy(lattice)/len(lattice)**2)
print(e[-1]/(len(lattice)**2))
M,E = metropolis(lattice,1000000,0.2,energy)
plt.plot(e)
plt.show()
def sweep(lattice ,beta, L, startEnergy, sequencelength = 1000):
    all_Energies = np.zeros(L)
    all_Magnets = np.zeros(L)
    all_Energies[0] = startEnergy
    all_Magnets[0] = lattice.sum()
    mplstyle.use('fast')
    fig, ax = plt.subplots(1,3, figsize= (16,9))
    plt.title(f"$\\beta J$ = {beta}")
    for t in range(1,L):
        E_p = 0
        E_t = 0
        old_lattice = lattice.copy()
        i = np.random.randint(0,len(lattice)) 
        j = np.random.randint(0,len(lattice))
        flipped_spin = lattice[i,j] 
        lattice[i,j] = flipped_spin*(-1)
        for n in range(2):
            E_t += lattice[i,(j+(-1)**n)%len(lattice)]
            E_t += lattice[(i+(-1)**n)%len(lattice),j]
            E_p += old_lattice[i,(j+(-1)**n)%len(lattice)]
            E_p += old_lattice[(i+(-1)**n)%len(lattice),j]

        E_t = -E_t*lattice[i,j]
        E_p = -E_p*flipped_spin
        deltaE = E_t-E_p
        if np.exp(-beta*(deltaE)) < np.random.random():
            lattice = old_lattice
            all_Energies[t] = all_Energies[t-1]
            all_Magnets[t] = all_Magnets[t-1]
        else:
            all_Energies[t] = deltaE + all_Energies[t-1]
            all_Magnets[t]  = lattice.sum()
        if (t%(sequencelength) == 0):
            mpl.rcParams['path.simplify'] = True
            mpl.rcParams['path.simplify_threshold'] = 1.0
            ax[0].imshow(lattice)
            ax[1].plot(np.arange(0,t,1),all_Energies[:t]/len(lattice)**2)
            ax[1].set_xlabel("t / simulation time")
            ax[1].set_ylabel("Energy")
            ax[2].plot(np.arange(0,t,1),all_Magnets[:t]/len(lattice)**2)
            ax[2].set_xlabel("t / simulation time")
            ax[2].set_ylabel("Magnetization")
            plt.show(block=False)
            plt.pause(0.001)
            ax[0].cla()
            ax[1].cla()
            ax[2].cla()
        
            
    return all_Energies,all_Magnets

BetaJ = np.arange(0.1,1,0.01)
Avg_Energies = np.zeros(len(BetaJ))
Avg_Magnets = np.zeros(len(BetaJ))
L = 50
for j, Bj in tqdm(enumerate(BetaJ), "a2 loop", total=len(BetaJ)):
    lattice = get_lattice(L)
    lattice_energy = get_energy(lattice)
    Magnets,Energy = metropolis(lattice,1000000,Bj,lattice_energy)
    Avg_Energies[j] = np.mean(Energy[200000:]/len(lattice)**2)
    Avg_Magnets[j] = np.abs(np.mean(Magnets[200000:]/len(lattice)**2))
plt.style.use('bmh')
cmap = get_cmap(50,"winter")
figa2, axa2 = plt.subplots(2, figsize= (16,9))
plt.suptitle("$\\Delta J \\beta$ = 0.01")
axa2[0].plot(BetaJ, Avg_Energies, label = f"Average Energies {L}x{L} Lattice \n Tmax = 1e6",color = cmap(20))
axa2[0].scatter([BetaJ[30]], [Avg_Energies[30]],s = 50, marker="+", color = "r", label =f"$\\beta J$ = 0.4 \n E = {Avg_Energies[30]:.3f}")
axa2[1].vlines([0.44068],0,1, linestyles= "dashed", colors = "grey", label = f"$J \\beta_c$ = {0.44068}")
#axa2[0].hlines([Avg_Energies[3]],0.1,1.75, linestyles= "dashed", colors = "grey")
axa2[0].set_xlabel("$\\beta J$")
axa2[0].set_ylabel("$\\bar{E}$")
axa2[0].legend()
axa2[1].plot(BetaJ, Avg_Magnets, label = f"Average Magnetization {L}x{L}  Lattice \n Tmax = 1e6",color = cmap(40))
axa2[1].set_xlabel("$\\beta J$")
axa2[1].set_ylabel("$\\bar{M}$")
axa2[1].legend()
figa2.savefig(f"{L}x{L}LatticeAvgEnergyMagnetoverT_critTemp_met.pdf")

